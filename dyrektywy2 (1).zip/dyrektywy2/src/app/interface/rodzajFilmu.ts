import { Kino } from './kino';

export enum RodzajFilmu{
    sensacyjny=1,
    kryminal,
    nieokreslono
}