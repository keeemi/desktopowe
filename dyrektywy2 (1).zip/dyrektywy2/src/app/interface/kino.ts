import { RodzajFilmu } from './rodzajFilmu';
export interface Kino{
    nazwa: string;
    zdjecie : string;
    adres : [{ulica : string, kodPocztowy: string, miejscowosc: string}];
    rodzajFilmu : RodzajFilmu;
}