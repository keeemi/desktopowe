import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Kino } from './interface/kino';
import {CommonModule} from '@angular/common';
import { RodzajFilmu } from './interface/rodzajFilmu';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  showImage1: boolean = false;
  showImage2: boolean = false;

  toggleImage1() {
    this.showImage1 = true;
    this.showImage2 = false;
  }

  toggleImage2() {
    this.showImage1 = false;
    this.showImage2 = true;
  }


kino : Kino = {
  nazwa: "Nowosolski Dom Kultury",
  zdjecie: "./assets/nowosolskiDomKultury.jpg",
  adres: [
    {ulica: "ul. Marszałka Józefa Piłsudskiego 49", kodPocztowy: "67-100", miejscowosc: "Nowa Sól"}
  ],
  rodzajFilmu: 1


}

kino2 : Kino = {
  nazwa: "Cinema City",
  zdjecie: "./assets/cinemaCity.jpg",
  adres: [
    {ulica: "ul. Wrocławska 17", kodPocztowy: "65-427", miejscowosc: "Zielona Góra"}
  ],
  rodzajFilmu: 2
  
}

kolory:string[] = ["red","blue","green"];
  wybor:number = 0;

  zmiana():void{
    this.wybor ++;
    if(this.wybor>=3) this.wybor = 0;
  }


}