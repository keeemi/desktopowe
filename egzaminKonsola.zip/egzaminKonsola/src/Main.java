import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        System.out.println("Podaj dluość tablicy większą od 20");
        try {
            int dlugosc = scanner.nextInt();

            while (dlugosc<=20){
                System.out.println("Podaj dluość tablicy większą od 20");
                dlugosc = scanner.nextInt();
            }

            Tablica tablica = new Tablica(dlugosc);

            System.out.println("podaj argument: ");

            int argument = scanner.nextInt();

            tablica.getTablica();


            System.out.println(tablica.pierwszeWystapienieWartosci(argument));

            tablica.nieparzyste();

            System.out.println(tablica.sredniaArytmetyczna());

        }
        catch(Exception e){
            System.out.println("Podano tekst, a nie liczbę.");
        }


    }
}