import java.util.ArrayList;
import java.util.Random;

public class Tablica {
    private int rozmiarTablicy;
    private int[] tablica;

    Random random = new Random();
    public Tablica(int rozmiarTablicy){
        this.rozmiarTablicy = rozmiarTablicy;
        this.tablica = new int[rozmiarTablicy];

        for (int i=0; i<rozmiarTablicy; i++){
            tablica[i] = random.nextInt(1000)+1;
        }
    }

    public void getTablica(){
        for (int j=0; j<tablica.length; j++){
            System.out.println((j+1)+": "+tablica[j]);
        }
    }
    int indeksPierwszegoWystapienia =-1;
    public int pierwszeWystapienieWartosci(int argument){

        for (int i=0; i<rozmiarTablicy; i++){
            if (argument==tablica[i]){
                indeksPierwszegoWystapienia = i+1;
                return indeksPierwszegoWystapienia;
            }
        }

        return indeksPierwszegoWystapienia;
    }

    public void nieparzyste(){
        tablica = this.tablica;
        int liczbaElementowListy = 0;
        ArrayList<Integer> lista = new ArrayList<Integer>();
        for (int l=0; l<tablica.length; l++){
            if (tablica[l]%2!=0){
                lista.add(tablica[l]);
                liczbaElementowListy++;
            }
        }
        System.out.println("Liczby nieparzyste: "+lista+"\nIlość liczb nieparzystych: "+liczbaElementowListy);
    }

    public int sredniaArytmetyczna(){
        int sumaLiczbTablicy = 0;
        int elementy = 0;
        for (int i=0; i<rozmiarTablicy; i++){
            sumaLiczbTablicy+=tablica[i];
        }
        int srednia = sumaLiczbTablicy/rozmiarTablicy;
        return srednia;
    }
}
