import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Osoba } from './interface/osoba';
import {CommonModule} from '@angular/common';
import { Plec } from './interface/plec';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, CommonModule],
  templateUrl: 'emiliakatta.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'Dyrektywy';
  showImage:boolean=false;
  enabled:boolean=true;

  osoba:Osoba = {
    name: "Jan",
    lastName: "Brzechwa",
    picture: "./brzechwa.jpg",
    /*ulica: "Kościuszki",
    numerDomu: 4,
    miejscowosc: "Nowa Sól",
    kodPocztowy: "67-100"*/
    adres : [
      {ulica:"Kościuszki",numerDomu: 4, miejscowosc: "Nowa Sól", kodPocztowy: "67-100"}
    ],
    sex: Plec.m

    
  }

  kolory:string[] = ["blue","yellow","green","red"];
  wybor:number = 0;

  zmiana():void{
    this.wybor ++;
    if(this.wybor>=4) this.wybor = 0;
  }

  }

  //adres : string[] = [this.osoba.ulica,this.osoba.numerDomu,this.osoba.miejscowosc,this.osoba.kodPocztowy];
  

  

  /*let tablica: Array<string> = [];
 
      for (let i = 0; i < osoba.length; i++) {
        tablica.push(this.osoba[i]?.miejscowosc);
      }*/




