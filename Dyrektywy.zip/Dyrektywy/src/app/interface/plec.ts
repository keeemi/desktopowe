export enum Plec{
    k=1,
    m,
    und
}