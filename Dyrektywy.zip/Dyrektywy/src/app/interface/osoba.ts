import { Plec } from './plec';

export interface Osoba{
  name:String;
  lastName:String;
  picture:String;
  /*ulica: String;
  numerDomu: number;
  miejscowosc: String;
  kodPocztowy: String;*/
  adres:[{ulica:String,numerDomu:number,miejscowosc:String,kodPocztowy:String}];
  sex:Plec;
}
