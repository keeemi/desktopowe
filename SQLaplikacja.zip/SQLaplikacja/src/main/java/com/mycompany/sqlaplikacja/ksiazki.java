/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sqlaplikacja;

/**
 *
 * @author egzamin
 */
public class ksiazki {
    private int id;
    private String nazwa;
    private String autor;
    private String wydawnictwo;
    
    public int getId(){
        return id;
    }
    
    public void setId(int id){
        this.id=id;
    }
    
    public String getAutor(){
        return autor;
    }
    
    public void setNazwa(String nazwa){
        this.nazwa=nazwa;
    }
    
    public String getWydawnictwo(){
        return wydawnictwo;
    }
    
    public void setWydawnictwo(String wydawnictwo){
        this.wydawnictwo=wydawnictwo;
    }
    
    public void setAutor(String autor){
        this.autor=autor;
    }
    
    public String insert(){
        return "INSERT INTO ksiazki (nazwa, autor, wydawnictwo) VALUES ('"
                +this.nazwa+"','"+this.autor+"','"+this.wydawnictwo+"');";
    }
}
